﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GujaratApollo.Models
{
    public class FetchUserData
    {
        public string VisitedNavigator { get; set; }
        public string VisitedUrl { get; set; }
    }
}