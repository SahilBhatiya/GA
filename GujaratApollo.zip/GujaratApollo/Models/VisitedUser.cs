﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GujaratApollo.Models
{
    public class VisitedUser
    {
        public TimeSpan Time { get; set; }
        public DateTime Date { get; set; }
        public string Navigator { get; set; }
        public string Url { get; set; }
    }
}