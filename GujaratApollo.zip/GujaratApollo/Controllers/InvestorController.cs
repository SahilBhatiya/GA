﻿using GujaratApollo.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;

namespace GujaratApollo.Controllers
{
    public class InvestorController : Controller
    {
        [Route("investors")]
        public ActionResult Index()
        {
            List<Book> BooksArray = ViewBag.Books = new List<Book>()
            {
                new Book()
                {
                    Name="gail - letter of offer",
                    Tag="buy_back_2021",
                    Date=new DateTime(2021,03,26),
                    Description="Content 1",
                    Location="/Content/Downloads/GAILoutcomeOfBoardMeetingwithResults30092020.pdf"
                },
                new Book()
                {
                    Name="gail - letter of offer",
                    Tag="buy_back_2021",
                    Date=new DateTime(2021,03,26),
                    Description="Content 1",
                    Location="/Content/Downloads/GAILoutcomeOfBoardMeetingwithResults30092020.pdf"
                },
                new Book()
                {
                    Name="gail - letter of offer",
                    Tag="buy_back_2021",
                    Date=new DateTime(2021,03,26),
                    Description="Content 1",
                    Location="/Content/Downloads/GAILoutcomeOfBoardMeetingwithResults30092020.pdf"
                },
                new Book()
                {
                    Name="gail - letter of offer",
                    Tag="buy_back_2021",
                    Date=new DateTime(2021,03,26),
                    Description="Content 1",
                    Location="/Content/Downloads/GAILoutcomeOfBoardMeetingwithResults30092020.pdf"
                },
                new Book()
                {
                    Name="gail - letter of offer",
                    Tag="buy_back_2019",
                    Date=new DateTime(2021,03,26),
                    Description="Content 1",
                    Location="/Content/Downloads/GAILoutcomeOfBoardMeetingwithResults30092020.pdf"
                },
                new Book()
                {
                    Name="gail - buyback - draft letter of offer",
                    Tag="buy_back_2020",
                    Date=new DateTime(2021,03,23),
                    Description="Content 2",
                    Location=""
                }
            };
            List<string> DisBooks = new List<string>();
            ViewBag.Tags = DisBooks = BooksArray.Select(x => x.Tag).Distinct().OrderByDescending(x=>x).ToList();
            return View();
        }
    }
}