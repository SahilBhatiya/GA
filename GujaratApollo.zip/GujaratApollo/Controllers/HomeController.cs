﻿using GujaratApollo.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace GujaratApollo.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController( ILogger<HomeController> logger )
        {
            _logger = logger;
        }
        public IActionResult Index()
        {
            return View( );
        }

        [Route("/About-Us")]
        public IActionResult About()
        {
            return View( );
        }
        [Route("/Qualities")]
        public IActionResult Qualities()
        {
            return View( );
        }

        [Route("/Services")]
        public IActionResult Services()
        {
            return View( );
        }

        [Route("/Contact-Us")]
        public IActionResult Contact()
        {
            return View( );
        }

        public IActionResult Privacy()
        {
            return View( );
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}