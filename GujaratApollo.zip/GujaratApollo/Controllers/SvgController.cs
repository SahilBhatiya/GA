﻿using Microsoft.AspNetCore.Mvc;

namespace GujaratApollo.Controllers
{
    public class SvgController : Controller
    {
        public IActionResult NewsEvents()
        {
            return View( );
        }

        public IActionResult EmployeeLogin()
        {
            return View( );
        }

        public IActionResult Mail()
        {
            return View( );
        }

        public IActionResult Mobile()
        {
            return View( );
        }

        public IActionResult TopArrow()
        {
            return View( );
        }

        public IActionResult Location()
        {
            return View( );
        }

        public IActionResult Instagram()
        {
            return View( );
        }

        public IActionResult LinkedIn()
        {
            return View( );
        }

        public IActionResult Facebook()
        {
            return View( );
        }

        public IActionResult Twitter()
        {
            return View( );
        }

        public IActionResult Settings()
        {
            return View( );
        }

        public IActionResult Tools()
        {
            return View( );
        }

        public IActionResult User()
        {
            return View( );
        }

        public IActionResult Work()
        {
            return View( );
        }

    }
}
