﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Web;

namespace GujaratApollo.Controllers
{
    
    public class AdminController : Controller
    {


        public ActionResult Login()
        {
            if (User.Identity.IsAuthenticated)
            {
                return RedirectToAction("Dashboard");
            }
            return View();
        }

/*        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(User user)
        {
            int isValid = userRepository.Loginuser(user);
            if (isValid == 1)
            {
                User SaveUser = userRepository.FetchSingleUser(user.Email);
                HttpCookie logUserName = new HttpCookie("logUserName");
                DateTime now = DateTime.Now;

                logUserName.Value = SaveUser.Name;
                logUserName.Expires = now.AddYears(50);

                Response.Cookies.Remove("logUserName");
                Response.Cookies.Add(logUserName);

                bool isRemember = user.isOnline == null ? false : user.isOnline == 1 ? true : false;

                FormsAuthentication.SetAuthCookie(user.Email, isRemember);
                return RedirectToAction("Dashboard");
            }
            else if(isValid == 0)
            {
                ModelState.AddModelError("", "Invalid Email Or Password!");
                return View();
            }
            else
            {
                ModelState.AddModelError("", "Please wait for some time! you are not authorised");
                return View();
            }
            
        }*/

        public ActionResult Dashboard()
        {
            return View();
        }

/*        [Route("Admin/Users")]
        public ActionResult Index()
        {
            return View(db.User.ToList());
        }*/

/*        public ActionResult Details(long? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            else
            {
                User user = userRepository.FetchSingleUser(id);
                if (user == null)
                {
                    return HttpNotFound();
                }
                else
                {
                    return View(user);
                }
            }
        }
*/

        [Route("Admin/Signup")]
        public ActionResult Create()
        {
            return View();
        }

/*        [HttpPost]
        [Route("Admin/Signup")]
        public JsonResult Create([Bind(Include = "Id,Name,Mobile,Role,isAuthorised,DateCreated,Password,LastLogin,Email,isOnline,Gender")] User user)
        {
            int isAdded = userRepository.CreateUser(user);
            if(isAdded == 1)
            {
                return Json(1, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(0, JsonRequestBehavior.AllowGet);
            }
        }*/

/*        public ActionResult Edit(long? Id)
        {
            if (Id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            else
            {
                User user = userRepository.FetchSingleUser(Id);
                if (user == null)
                {
                    return HttpNotFound();
                }
                else
                {
                    ViewBag.user = user;
                    return View(user);
                }
            }
        }*/

/*        public ActionResult EditUser(string email)
        {
            if (email == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            else
            {
                User user = userRepository.FetchSingleUser(email);
                if (user == null)
                {
                    return HttpNotFound();
                }
                else
                {
                    ViewBag.user = user;
                    return View(user);
                }
            }
        }*/

/*        [HttpPost]
        public JsonResult Edit(User user)
        {
            int isModified = userRepository.EditUser(user);
            if(isModified == 1)
            {
                User SaveUser = userRepository.FetchSingleUser(user.Email);
                HttpCookie logUserName = new HttpCookie("logUserName");
                DateTime now = DateTime.Now;

                logUserName.Value = SaveUser.Name;
                logUserName.Expires = now.AddYears(50);

                Response.Cookies.Remove("logUserName");
                Response.Cookies.Add(logUserName);

                return Json( 1, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(0, JsonRequestBehavior.AllowGet);
            }
        }*/


/*        [HttpPost]
        public JsonResult DeleteSingleUser(User user)
        {
            return Json(userRepository.DeleteSingleUser(user), JsonRequestBehavior.AllowGet);
        }*/

/*        [HttpPost]
        public JsonResult DeleteUnAuthrised()
        {
            return Json(userRepository.DeleteUnAuthrised(), JsonRequestBehavior.AllowGet);
        }*/

/*        [HttpPost]
        public JsonResult GetSingleUserDetails(User Fuser)
        {
            User user = userRepository.FetchSingleUser(Fuser.Email);
            var json = JsonConvert.SerializeObject(user);
            return Json(json, JsonRequestBehavior.AllowGet);
        }*/

/*        [HttpPost]
        public JsonResult LogoutUser()
        {
            try
            {
                FormsAuthentication.SignOut();
                return Json(1, JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json(0, JsonRequestBehavior.AllowGet);
            }
            
        }*/

/*        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }*/
    }
}
