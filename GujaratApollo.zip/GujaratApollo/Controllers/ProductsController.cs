﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GujaratApollo.Controllers
{
    public class ProductsController : Controller
    {
        [Route("products")]
        public ActionResult Index()
        {
            return View();
        }
    }
}