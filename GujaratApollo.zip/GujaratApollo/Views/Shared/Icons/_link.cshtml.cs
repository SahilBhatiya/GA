using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GujaratApollo.Views.Shared.Icons;

public class _link : PageModel
{
    public void OnGet()
    {
        
    }
}